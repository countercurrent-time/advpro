import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset, Dataset
from ast import parse, NodeVisitor
import astunparse
import warnings
from torch.utils.data import DataLoader

warnings.filterwarnings("ignore")

class AdvPro:
    def __init__(self, model_name, dataset_path):
        self.model_name = model_name
        self.dataset_path = dataset_path
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name)
        self.model.eval()
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model.to(self.device)
        
        # Load dataset
        self.dataset = self._load_dataset()
        self.dataloader = DataLoader(self.dataset, batch_size=1, shuffle=False)

    def _load_dataset(self):
        # Example dataset structure (replace with your actual dataset)
        data = {
            'code_prompt': ['def example_func(...): ...'],
            'secure_code': ['return secure_code()'],
            'vulnerable_code': ['return vulnerable_code()']
        }
        return Dataset.from_dict(data)

    def _forward_computation(self, input_ids, attention_mask):
        outputs = self.model(input_ids.to(self.device), attention_mask.to(self.device))
        return outputs.logits

    def _compute_attribution(self, logits, secure_target, vulnerable_target):
        # Compute probabilities
        secure_prob = logits[0, -1, secure_target]
        vulnerable_prob = logits[0, -1, vulnerable_target]
        
        # Compute gradient
        (secure_prob - vulnerable_prob).backward()
        attribution = self.model.get_input_embeddings().weight.grad
        
        return attribution

    def _get_importance_scores(self, code):
        input_ids = self.tokenizer(code, return_tensors='pt').input_ids
        attention_mask = self.tokenizer(code, return_tensors='pt').attention_mask
        
        # Forward pass
        logits = self._forward_computation(input_ids, attention_mask)
        
        # Assume secure and vulnerable targets are token indices
        secure_target = 1  # Replace with actual target token indices
        vulnerable_target = 2  # Replace with actual target token indices
        
        # Compute attribution
        attribution = self._compute_attribution(logits, secure_target, vulnerable_target)
        
        # Compute importance scores
        importance_scores = torch.norm(attribution, dim=1)
        return importance_scores

    def _parse_code(self, code):
        return parse(code)

    def attack(self):
        for idx, sample in enumerate(self.dataloader):
            code_prompt = sample['code_prompt'][0]
            secure_code = sample['secure_code'][0]
            vulnerable_code = sample['vulnerable_code'][0]
            
            # Get importance scores
            importance_scores = self._get_importance_scores(code_prompt)
            
            # Parse code to AST
            ast_root = self._parse_code(code_prompt)
            
            # Apply semantic-preserving mutations
            mutated_prompts = self._apply_mutations(ast_root, importance_scores)
            
            # Check model output
            for mutated_prompt in mutated_prompts:
                # Generate model output
                input_ids = self.tokenizer(mutated_prompt, return_tensors='pt').input_ids.to(self.device)
                output = self.tokenizer.decode(self.model.generate(input_ids)[0])
                
                # Check if vulnerable code is generated
                if vulnerable_code in output and secure_code not in output:
                    print(f"Adversarial prompt found for sample {idx}: {mutated_prompt}")
                    return mutated_prompt
                
            print(f"No adversarial prompt found for sample {idx}")
    
    def _apply_mutations(self, ast_root, importance_scores):
        # Implement mutation strategies here
        # Example: Apply identifier mutation on top 3 important nodes
        mutated_prompts = []
        
        # Convert AST to code
        original_code = astunparse.unparse(ast_root)
        
        # Apply mutations (example: rename identifiers)
        identifier_mutator = IdentifierMutator()
        modified_code = identifier_mutator.visit(ast_root)
        mutated_prompts.append(astunparse.unparse(modified_code))
        
        return mutated_prompts

class IdentifierMutator(NodeVisitor):
    def __init__(self):
        self.count = 0

    def visit_Name(self, node):
        node.id = f"var_{self.count}"
        self.count += 1
        return node

if __name__ == '__main__':
    advpro = AdvPro('Salesforce/codegen-2B-mono', '../AdvProDataset')
    advpro.attack()