import ast
import astunparse

class MutationStrategy:
    def apply(self, node):
        pass

class IdentifierRenamer(MutationStrategy):
    def __init__(self, old_to_new=None):
        self.old_to_new = old_to_new if old_to_new else {}

    def apply(self, node):
        class Renamer(ast.NodeTransformer):
            def __init__(self, old_to_new):
                self.old_to_new = old_to_new

            def visit_Name(self, node):
                if node.id in self.old_to_new:
                    new_id = self.old_to_new[node.id]
                    return ast.copy_location(ast.Name(id=new_id, ctx=node.ctx), node)
                return node

        renamer = Renamer(self.old_to_new)
        return renamer.visit(node)

class AssignTransformer(MutationStrategy):
    def apply(self, node):
        class AssignTransformer(ast.NodeTransformer):
            def visit_Assign(self, node):
                
                
                
                
                return node

        transformer = AssignTransformer()
        return transformer.visit(node)

class ConditionalExprTransformer(MutationStrategy):
    def apply(self, node):
        class ConditionalExprTransformer(ast.NodeTransformer):
            def visit_IfExp(self, node):
                
                new_if = ast.If(
                    test=node.test,
                    body=[ast.Expr(value=node.body)],
                    orelse=[ast.Expr(value=node.orelse)],
                )
                return ast.copy_location(new_if, node)

            def visit_If(self, node):
                
                
                new_test = ast.Call(
                    func=ast.Name(id='not', ctx=ast.Load()),
                    args=[node.test],
                    keywords=[]
                )
                
                new_body = node.orelse
                new_orelse = node.body
                return ast.copy_location(
                    ast.If(test=new_test, body=new_body, orelse=new_orelse),
                    node
                )

        transformer = ConditionalExprTransformer()
        return transformer.visit(node)

class LambdaToFunctionTransformer(MutationStrategy):
    def apply(self, node):
        class LambdaToFunctionTransformer(ast.NodeTransformer):
            def visit_Lambda(self, node):
                
                func_def = ast.FunctionDef(
                    name='lambda_func',
                    args=node.args,
                    body=[ast.Return(value=node.body)],
                    decorator_list=[],
                )
                return ast.copy_location(func_def, node)

        transformer = LambdaToFunctionTransformer()
        return transformer.visit(node)

class ComprehensionToListCompTransformer(MutationStrategy):
    def apply(self, node):
        class ComprehensionTransformer(ast.NodeTransformer):
            def visit_ListComp(self, node):
                
                loop_variables = []
                for generator in node.generators:
                    target = generator.target
                    iter = generator.iter
                    ifs = generator.ifs
                    loop_variables.append(target)

                    
                    for_loop = ast.For(
                        target=target,
                        iter=iter,
                        body=ifs + [ast.Expr(value=node.elt)],
                        orelse=[],
                    )
                    return ast.copy_location(for_loop, node)

        transformer = ComprehensionTransformer()
        return transformer.visit(node)

class ExprToAssignmentTransformer(MutationStrategy):
    def apply(self, node):
        class ExprToAssignmentTransformer(ast.NodeTransformer):
            def visit_Expr(self, node):
                
                new_name = ast.Name(id='result', ctx=ast.Store())
                new_assign = ast.Assign(
                    targets=[new_name],
                    value=node.value,
                )
                return ast.copy_location(new_assign, node)

        transformer = ExprToAssignmentTransformer()
        return transformer.visit(node)

class AugmentedAssignToAssignTransformer(MutationStrategy):
    def apply(self, node):
        class AugmentedAssignTransformer(ast.NodeTransformer):
            def visit_AugAssign(self, node):
                
                right = ast.copy_location(
                    ast.copy_location(
                        ast.BinOp(
                            left=node.target,
                            op=node.op,
                            right=node.value,
                        ),
                        node.value
                    ),
                    node
                )
                return ast.copy_location(
                    ast.Assign(
                        targets=[node.target],
                        value=right,
                    ),
                    node
                )

        transformer = AugmentedAssignTransformer()
        return transformer.visit(node)

def get_mutation_strategies():
    return [
        IdentifierRenamer(),
        AssignTransformer(),
        ConditionalExprTransformer(),
        LambdaToFunctionTransformer(),
        ComprehensionToListCompTransformer(),
        ExprToAssignmentTransformer(),
        AugmentedAssignToAssignTransformer(),
    ]

def apply_mutations(ast_root, strategies, num_mutations=3):
    mutated_asts = []
    for strategy in strategies[:num_mutations]:
        mutated_ast = strategy.apply(ast_root)
        mutated_asts.append(mutated_ast)
    return mutated_asts


if __name__ == '__main__':
    code = """
def example_func(arg1, arg2):
    return arg1 + arg2 if arg1 > 0 else arg1 - arg2
    """
    ast_root = ast.parse(code)
    
    strategies = get_mutation_strategies()
    mutated_asts = apply_mutations(ast_root, strategies, num_mutations=3)
    
    for i, ast_node in enumerate(mutated_asts):
        print(f"Mutated Code {i+1}:")
        print(astunparse.unparse(ast_node))